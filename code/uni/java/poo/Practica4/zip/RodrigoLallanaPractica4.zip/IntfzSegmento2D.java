public interface IntfzSegmento2D extends IntfzPunto2D{

  void longitud();

}
