public interface IntfzSegmento3D extends IntfzPunto3D{
  int  setSegmento(IntfzPunto3D p1, IntfzPunto3D p2);
  void getSegmento();
  void longitud();
}
